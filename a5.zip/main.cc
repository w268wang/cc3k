#include <iostream>

using namespace std;

int main() {
	bool endOfGame = false;
	cout<<"Welcome to the world of CC3K."<<endl;
	while(!endOfGame) {
		while(true) {
			int floor = 1;
			Floor *f = 0;
			player *pc = 0;
			string s;
			cout<<"First, you need to specify the race you wish to be."<<endl;
			cout<<"h: human (140 HP, 20 Atk, 20 Def, have a 50% increase to their score.)"<<endl;
			cout<<"d: dwarf (100 HP, 20 Atk, 30 Def, gold is doubled in value)"<<endl;
			cout<<"e: elves (140 HP, 30 Atk, 10 Def, negative potions have positive effect)"<<endl;
			cout<<"o: orc (180 HP, 30 Atk, 25 Def, gold is worth half value)"<<endl;
			cout<<"Please choose(h, d, e or o):"<<endl;
			cin>>s;
			if(s=="h") pc=new Human();
			else if(s=="d") pc=new Dwarf();
			else if(s=="e") pc=new Elves();
			else if(s=="o") pc=new Orc();
			else {cout<<"What are you doing!"<<endl; endOfRond=true; continue;}
			f = new floor(pc, floor);
			f->init();
			cout << (*f);
			endOfGame = true;
			break;
		}
	}
}

