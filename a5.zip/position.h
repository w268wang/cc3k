#ifndef _POSITION_H_
#define _POSITION_H_

class Position {
	int r, s;
	Position();
	~Position();
};

#endif
