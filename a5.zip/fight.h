#ifndef _FIGHT_H_
#define _FIGHT_H_

#include "player.h"
#include "enemy.h"

class Fight {
	//Player *p;
	//Enemy *e;
	//need to also notify the cell

	public:
	Fight();
	~Fight();
	
	void start(Player *p, Enemy *e);
};

#endif
