/* 
 * this will have a full 79*30 map
 * wall
 */

#ifndef _GRID_H_
#define _GRID_H_

#include "textdisplay.h"

class Grid {
  Cell **theGrid;
  TextDisplay *td;
  Fight *f;
  int floor;

  void clearGrid();   // Frees the grid.

 public:
  Grid();
  ~Grid();

  int isOver();
  void init();
  void init(int r, int c);
  void move(int r, int c);
  void battle(int r, int c);
  friend std::ostream &operator<<(std::ostream &out, const Grid &g);
};

#endif
